create database Rayspitching;
use Rayspitching;
SHOW TABLES;

select * from last_data_rays;
select * from data_reference_stats;

/* ALTER table last_data_rays
add constraint PK_pitcher primary key (pitcher)*/

-- Question 1 AVG Pitches Per at Bat Analysis
select pitch_number from last_data_rays;
-- 1a AVG Pitches Per At Bat (LastPitchRays)
SELECT AVG(pitch_number) AS Average_pitchat_bat
 from last_data_rays;

-- 1b AVG Pitches Per At Bat Home Vs Away (LastPitchRays) -> Union
SELECT 
'Home' TypeofGame,
AVG(pitch_number) AS Average_pitchat_bat
 from last_data_rays
 where home_team ='TB'
 union
 SELECT 
'Away' TypeofGame,
AVG(pitch_number) AS Average_pitchat_bat
 from last_data_rays
 where away_team ='TB'
 ;
 
-- 1c AVG Pitches Per At Bat Lefty Vs Righty  -> Case Statement 

select 
AVG (CASE WHEN batter_position ='L' THEN pitch_number end) LeftyatBat,
AVG (CASE WHEN batter_position ='R' THEN pitch_number end) RightyatBat
from last_data_rays;

-- 1d AVG Pitches Per At Bat Lefty Vs Righty Pitcher | Each Away Team -> Partition By
select
distinct 
home_team,
Pitcher_Position,
avg(pitch_number) over (partition by home_team, Pitcher_Position) As Avg_Pitch_number
from last_data_rays
where away_team ='TB';

-- 1e Top 3 Most Common Pitch for at bat 1 through 10, and total amounts (LastPitchRays)
-- part of query
with total_pitch_sequence as (
	select 
		distinct
		pitch_name,
		pitch_number,
		count(pitch_name) over (partition by pitch_name, pitch_number) pitch_count
	from last_data_rays
	where pitch_number <11
)
select * ,
	rank () over (partition by pitch_number order by pitch_count desc) pitch_count_ranking
from total_pitch_sequence
;
-- fulll query with CTE
WITH total_pitch_sequence AS (
    SELECT DISTINCT
        pitch_name,
        pitch_number,
        COUNT(pitch_name) OVER (PARTITION BY pitch_name, pitch_number) AS pitch_count
    FROM last_data_rays
    WHERE pitch_number < 11
),
pitchfrequencyrankquery AS (
    SELECT
        pitch_name,
        pitch_number,
        pitch_count,
        RANK() OVER (PARTITION BY pitch_number ORDER BY pitch_count DESC) AS pitch_count_ranking
    FROM total_pitch_sequence
)
SELECT *
FROM pitchfrequencyrankquery
WHERE pitch_count_ranking < 4;


-- 1f AVG Pitches Per at Bat Per Pitcher with 20+ Innings | Order in descending (LastPitchRays + RaysPitchingStats)

select *
from last_data_rays LDR
join data_reference_stats DRS
ON DRS.pitcher = LDR.pitcher;

select DRS.Name,
AVG(pitch_number) AvgPitches
from last_data_rays LDR
join data_reference_stats DRS
ON DRS.pitcher = LDR.pitcher
where IP>20
group by DRS.Name
order by AvgPitches desc;

-- Question 2 Last Pitch Analysis
select * from last_data_rays;
select * from data_reference_stats;

-- 2a Count of the Last Pitches Thrown in Desc Order (LastPitchRays)
select pitch_name, count(*) timesthrown
from last_data_rays
group by pitch_name
order by count(*) desc;

-- 2b Count of the different last pitches Fastball or Offspeed (LastPitchRays)
select
	sum(case when pitch_name in ('4-Seam Fastball','Cutter') then 1 else 0 end) Fastball,
    sum(case when pitch_name not in ('4-Seam Fastball','Cutter') then 1 else 0 end) offspeed
from last_data_rays;
-- 2c Percentage of the different last pitches Fastball or Offspeed (LastPitchRays)

select
	100 * sum(case when pitch_name in ('4-Seam Fastball','Cutter') then 1 else 0 end) / count(*) Fastball_percentage,
    100 * sum(case when pitch_name not in ('4-Seam Fastball','Cutter') then 1 else 0 end) / count(*) offspeed_percentage
from last_data_rays;

-- rounded Result
SELECT
    ROUND(100 * SUM(CASE WHEN pitch_name IN ('4-Seam Fastball', 'Cutter') THEN 1 ELSE 0 END) / COUNT(*), 2) AS Fastball_percentage,
    ROUND(100 * SUM(CASE WHEN pitch_name NOT IN ('4-Seam Fastball', 'Cutter') THEN 1 ELSE 0 END) / COUNT(*), 2) AS offspeed_percentage
FROM last_data_rays;


-- 2d Top 5 Most common last pitch for a Relief Pitcher vs Starting Pitcher (LastPitchRays + RaysPitchingStats)
-- partial
select DRS.POS, LDR.pitch_name, count(*)  as Pitch_count
from last_data_rays LDR
join data_reference_stats DRS
ON DRS.pitcher = LDR.pitcher
group by DRS.POS, LDR.pitch_name;

-- PArtial Full
select
a.POS,
a.pitch_name, 
a.Pitch_count,
rank() over (partition by a.POS order by a.Pitch_count desc) Pitch_rank
from (
select DRS.POS, LDR.pitch_name, count(*)  as Pitch_count
from last_data_rays LDR
join data_reference_stats DRS
ON DRS.pitcher = LDR.pitcher
group by DRS.POS, LDR.pitch_name)a;

-- Full
select * 
from (
select
a.POS,
a.pitch_name, 
a.Pitch_count,
rank() over (partition by a.POS order by a.Pitch_count desc) Pitch_rank
from (
select DRS.POS, LDR.pitch_name, count(*)  as Pitch_count
from last_data_rays LDR
join data_reference_stats DRS
ON DRS.pitcher = LDR.pitcher
group by DRS.POS, LDR.pitch_name)a
)b
where b.Pitch_rank <6;

-- Question 3 Homerun analysis
select * from last_data_rays;
select * from data_reference_stats;
-- 3a What pitches have given up the most HRs (LastPitchRays) 

-- 
select * 
	from last_data_rays
    where hit_location is null and bb_type ='fly_ball';
    
select pitch_name, count(*) HRs
from last_data_rays
where events = 'home_run'
group by pitch_name
order by HRs DESC;
    
-- 3b Show HRs given up by zone and pitch, show top 5 most common
select ZONE, pitch_name, count(*) HRs
from last_data_rays
where events = 'home_run'
group by pitch_name
order by HRs DESC
limit 5;
-- 3c Show HRs for each count type -> Balls/Strikes + Type of Pitcher
select DRS.POS, LDR.balls, LDR.strikes, count(*) HRs
from last_data_rays LDR
join data_reference_stats DRS ON DRS.pitcher = LDR.pitcher;
-- 3d Show Each Pitchers Most Common count to give up a HR (Min 30 IP)
-- partial
with hrcountpitcher as (
select DRS.Name, LDR.balls, LDR.strikes, count(*) HRs
from last_data_rays LDR
join data_reference_stats DRS ON DRS.pitcher = LDR.pitcher
where events = 'home_run' and IP >30
group by DRS.Name, LDR.balls, LDR.strikes
)
select
hcp.Name,
hcp.balls,
hcp.strikes,
hcp.HRs,
rank() over (partition by Name, balls, strikes order by HRs	desc) hrrank
from hrcountpitcher hcp;

-- Full 

with hrcountpitcher as (
select DRS.Name, LDR.balls, LDR.strikes, count(*) HRs
from last_data_rays LDR
join data_reference_stats DRS ON DRS.pitcher = LDR.pitcher
where events = 'home_run' and IP >30
group by DRS.Name, LDR.balls, LDR.strikes
),
hrcountsrank as (
select
hcp.Name,
hcp.balls,
hcp.strikes,
hcp.HRs,
rank() over (partition by Name, balls, strikes order by HRs	desc) hrrank
from hrcountpitcher hcp)
select * from hrcountsrank
where hrrank =1
;

with hrcountpitcher as (
select DRS.Name, LDR.balls, LDR.strikes, count(*) HRs
from last_data_rays LDR
join data_reference_stats DRS ON DRS.pitcher = LDR.pitcher
where events = 'home_run' and IP >30
group by DRS.Name, LDR.balls, LDR.strikes
),
hrcountsrank as (
select
hcp.Name,
hcp.balls,
hcp.strikes,
hcp.HRs,
rank() over (partition by Name, balls, strikes order by HRs	desc) hrrank
from hrcountpitcher hcp)
select ht.Name, ht.balls,ht.strikes, ht.HRs
from hrcountsrank ht
where hrrank =1;
;
-- Question 4 Shane McClanahan
select * from last_data_rays;
select * from data_reference_stats;

-- 4a AVG Release speed, spin rate,  strikeouts, most popular zone ONLY USING LastPitchRays
select 
avg(release_speed) AvgReleasedSpeed,
avg(release_spin_rate) AvgSpinRate,
sum(case when events ='strikeout' then 1 else 0 end) strikeouts
from last_data_rays
where player_name = 'McClanahan, Shane';

select pitcher, zone, count(*) as count
from last_data_rays
where player_name = 'McClanahan, Shane'
group by zone
order by count(*) desc;

-- join

select
avg(release_speed) AvgReleaseSpeed,
avg(release_spin_rate) AvgSpinRate,
sum(case when events = 'strikeout' then 1 else 0 end) strikeouts,
Max(zones.zone) as Zone
from 	last_data_rays

join ( 
select pitcher, zone, count(*) Zonenum
from last_data_rays
where 	player_name = 'McClanahan, Shane'
group by pitcher,zone
order by count(*) desc
limit 1
)
zones on zones.pitcher = LPR.pitcher
where 	player_name = 'McClanahan, Shane';
-- Wrong one

-- Correct One
SELECT
    AVG(release_speed) AS AvgReleaseSpeed,
    AVG(release_spin_rate) AS AvgSpinRate,
    SUM(CASE WHEN events = 'strikeout' THEN 1 ELSE 0 END) AS strikeouts,
    MAX(zones.zone) AS Zone
FROM last_data_rays
JOIN (
    SELECT
        pitcher,
        zone,
        COUNT(*) AS Zonenum
    FROM last_data_rays
    WHERE player_name = 'McClanahan, Shane'
    GROUP BY pitcher, zone
    ORDER BY COUNT(*) DESC
    LIMIT 1
) AS zones ON zones.pitcher = last_data_rays.pitcher
WHERE player_name = 'McClanahan, Shane';


-- 4b top pitches for each infield position where total pitches are over 5, rank them

select * from (

select pitch_name, count(*) timeshit, ' Third' Position
from last_data_rays
where hit_location = 5 and player_name = 'McClanahan, Shane'
group by pitch_name
union 
select pitch_name, count(*) timeshit, ' Short' Position
from last_data_rays
where hit_location = 6 and player_name = 'McClanahan, Shane'
group by pitch_name
union
select pitch_name, count(*) timeshit, ' Second' Position
from last_data_rays
where hit_location = 4 and player_name = 'McClanahan, Shane'
group by pitch_name
union
select pitch_name, count(*) timeshit, ' first' Position
from last_data_rays
where hit_location = 3 and player_name = 'McClanahan, Shane'
group by pitch_name
)a

where timeshit >4
order by timeshit desc;


-- 4c Show different balls/strikes as well as frequency when someone is on base 

select balls, strikes, count(*) as frequency
from last_data_rays
where(on_3b is not null or on_2b is not null or on_1b is not null)
and player_name = 'McClanahan, Shane'
group by balls, strikes
order by frequency desc;
-- 4d What pitch causes the lowest launch speed

select pitch_name, avg(launch_speed) as LaunchSpeed
from last_data_rays
where player_name ='McClanahan, Shane'
group by pitch_name
order by launchSpeed desc
limit 1;

