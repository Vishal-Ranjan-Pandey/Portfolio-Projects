create database Pizza;
use pizza;

select * from pizza_sales;

-- Add a new column with the desired data type (DATE)
ALTER TABLE pizza_sales
ADD new_order_date DATE;

-- Update the new column with the data from the old column
UPDATE pizza_sales
SET new_order_date = STR_TO_DATE(order_date, '%d-%m-%Y'); -- Adjust the date format as needed

-- Drop the old column (optional)
ALTER TABLE pizza_sales
DROP COLUMN order_date;

-- Rename the new column to match the old one (optional)
ALTER TABLE pizza_sales
CHANGE COLUMN new_order_date order_date DATE;

select * from pizza_sales;

select sum(total_price) As Total_Revenue from pizza_sales;

select (total_price)/count(distinct order_id) as Avg_Order_Value from pizza_sales;

select sum(quantity) as total_quantity_sold from pizza_sales;

select count(distinct order_id) as Total_sales from pizza_sales;

select sum(quantity)/count(distinct order_id) Avg_pizza_per_order from pizza_sales;

SELECT ROUND(SUM(quantity) / COUNT(DISTINCT order_id), 2) As Avg_pizza_per_order
FROM pizza_sales;

SELECT DAYNAME(order_date) AS order_day, COUNT(DISTINCT order_id) AS total_orders
FROM pizza_sales
GROUP BY DAYNAME(order_date)
ORDER BY MIN(order_date); -- Optional: Order by the actual order date for chronological order


SELECT MONTHNAME(order_date) AS Month_Name, COUNT(DISTINCT order_id)
FROM pizza_sales
GROUP BY MONTHNAME(order_date);

SELECT MONTHNAME(order_date) AS Month_Name, COUNT(DISTINCT order_id) as Total_orders
FROM pizza_sales
GROUP BY MONTHNAME(order_date)
order by Total_orders desc;

select pizza_category, 
sum(total_price) * 100 / (
select sum(total_price)
 from pizza_sales) as Percentage_of_total_sales
	from pizza_sales
    group by pizza_category;
    
 
select pizza_category, 
sum(total_price) as total_sales,
sum(total_price) * 100 / (
select sum(total_price)
 from pizza_sales) as Percentage_of_total_sales
	from pizza_sales
    group by pizza_category;


select pizza_category, 
sum(total_price) as total_sales,
sum(total_price) * 100 / (
select sum(total_price)
 from pizza_sales where month(order_date) =1) as Percentage_of_total_sales
	from pizza_sales
    where month(order_date) = 1
    group by pizza_category;
    
select pizza_category, 
sum(total_price) as total_sales,
round(sum(total_price) * 100 / (
select sum(total_price)
 from pizza_sales where month(order_date) =1),2) as Percentage_of_total_sales
	from pizza_sales
    where month(order_date) = 1
    group by pizza_category
    order by Percentage_of_total_sales desc;    


select pizza_size, 
round(sum(total_price),2) as total_sales,
round(sum(total_price) * 100 / (
select sum(total_price)
 from pizza_sales where month(order_date) =1),2) as Percentage_of_total_sales
	from pizza_sales
    where month(order_date) = 1
    group by pizza_category
    order by Percentage_of_total_sales desc;  
    

select pizza_size, 
round(sum(total_price),2) as total_sales,
round(sum(total_price) * 100 / (
select sum(total_price)
 from pizza_sales where quarter(order_date) =1),2) as Percentage_of_total_sales
	from pizza_sales
    where quarter(order_date) = 1
    group by pizza_category
    order by Percentage_of_total_sales desc; 
    
    
select pizza_name, round( sum(total_price),2) total_Rvenue from pizza_sales
group by pizza_name
order by total_Rvenue desc
limit 5;

select pizza_name, round( sum(total_price),2) total_Rvenue from pizza_sales
group by pizza_name
order by total_Rvenue
limit 5;

select pizza_name, round( sum(quantity),2) totalQuantity from pizza_sales
group by pizza_name
order by totalQuantity desc
limit 5;

