create DATABASE ECommerce;
use ECommerce;

select * from Transactions;

--  While importing the data the dates are imported as the text not as the date. So we need to alter the table and change the datatype.

-- Add a new column with the desired data type (DATE)
ALTER TABLE Transactions
ADD Transactions_Date DATE;

-- Update the new column with the data from the old column
UPDATE Transactions
SET Transactions_Date = STR_TO_DATE(tr_date, '%m/%d/%Y'); -- Adjust the date format as needed
-- Similarily
ALTER TABLE Transactions
ADD first_sold_date DATE;
UPDATE Transactions
SET first_sold_date = STR_TO_DATE(product_first_sold_date, '%m/%d/%Y');
-- Drop the columns
ALTER TABLE Transactions
DROP COLUMN tr_date;

ALTER TABLE Transactions
DROP COLUMN product_first_sold_date;

-- after this we are adding the primary key to the table transaction. The column will p_id.
alter table Transactions
modify column p_id varchar(255),
add primary key (p_id(255));
describe table Transactions;

create table product(
product_ID int,
category varchar(15)
);

alter table product
modify column product_id varchar(10);

insert into product (product_ID, category)
values
('Pr0923519','Electric'),
('Pr0923520','Non- Electric'),
('Pr0923515','Electric'),
('Pr0923514','Non- Electric'),
('Pr0923507','Mortor'),
('Pr0923525','Mortor'),
('Pr09235150','Electric'),
('Pr0923503','Essentials'),
('Pr0923521','Essentials'),
('Pr0923511','Luxuary'),
('Pr0923503','Essentials'),
('Pr09235013','Luxuary'),
('Pr09235005','Luxuary'),
('Pr09235006','Luxuary'),
('Pr09235005','Essentials');

select * from product;

create table manufacturer(
product_id varchar(10),
Manufacturer varchar(15));

insert into manufacturer (product_id,Manufacturer)
values
('Pr0923519','South Korea'),
('Pr0923520','London'),
('Pr0923515','Delhi'),
('Pr0923514','Italy'),
('Pr0923507','South Korea'),
('Pr0923525','London'),
('Pr09235150','Chennai'),
('Pr0923503','USA'),
('Pr0923521','London'),
('Pr0923511','Soingapoor'),
('Pr0923503','Durban'),
('Pr09235013','North Korea'),
('Pr09235005','London'),
('Pr09235006','China'),
('Pr09235005','Mumbai');

select * from transactions;

select distinct product_line from transactions;
-- finding most profitable and least profitable product.
select product_line, list_price, standard_cost, round(list_price - standard_cost,2) as profit
from transactions
group by product_line
order by profit;

select product_line, product, list_price, standard_cost, round(list_price - standard_cost,2) as profit
from transactions
group by product
order by profit;

select product, list_price, standard_cost, round(list_price - standard_cost,2) as profit
from transactions
group by product
order by profit;

select product, list_price, standard_cost, round(list_price - standard_cost,2) as profit
from transactions
group by product_line
order by profit;

select product_line, product from transactions
where list_price - standard_cost > 0;

select product_line, product from transactions
where list_price - standard_cost < 0;

select product_line, product, list_price, standard_cost from transactions
where list_price - standard_cost < 0;

SELECT
    product_line,
    product,
    list_price,
    standard_cost,
    ROUND(list_price - standard_cost, 2) AS profit
FROM
    transactions
WHERE
    product_line = 'Standard' and
    product = 'Nio Cycles'
ORDER BY
    profit;

-- As the NIO CYCLES has different trend, some of them is in loss and profit, thus lets analyse them separetly

with CTE_NIO AS (
	SELECT product_line, product, list_price, standard_cost from transactions
    where product = 'Nio Cycles')
    select * from CTE_NIO;
    
    select product from CTE_NIO
    where list_price < standard_cost;
    -- As the CTE cannot be accessed thus creating the View using same criteria
    
    create VIEW NIO_View as
    SELECT product_line, product, list_price, standard_cost from transactions
    where product = 'Nio Cycles';
    
    select * from NIO_view;
    
 select product, list_price, standard_cost from NIO_View
    where list_price < standard_cost;
    
   -- deleting the view
   drop view NIO_view;
select * from transactions
where order_status != 'Approved';
   -- first we should analyze the order_status and the reason behind its cancellations
   -- lets create a view with the cancelled transactions
create view Cancelled_view as
select * from transactions
where order_status = 'Cancelled';

select * from Cancelled_view;

select distinct product_line from Cancelled_view;
-- The most of the canclled product lines are Standard, Road, Mountain and Touring.
select 'Mode of Purchase' from cancelled_view;

select distinct product_line from transactions;

select product_line, Avg (Transactions_date -first_sold_date) as Diff_date
from cancelled_view
group by product_line;
-- we can see there is avg difference date is more, these reasons can be a reason behind the cancellation.

-- Now lets comare the difference of the approved data

create view Approved_view as
select * from transactions
where order_status != 'Cancelled';

select * from Approved_view;

select product_line, Avg (Transactions_date -first_sold_date) as Diff_date
from Approved_view
group by product_line;

select * from Approved_view;

-- we can say that the difference between order date is more, thus the company need to improve its delivery time.
-- drop view Cancelled_view;
-- Now we are identifying the profitable products and non profitable products using view and will analyze further on that

select * from transactions
where product_class != product_size;
    